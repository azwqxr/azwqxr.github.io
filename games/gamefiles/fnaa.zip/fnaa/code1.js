gdjs.ingameCode = {};
gdjs.ingameCode.localVariables = [];
gdjs.ingameCode.idToCallbackMap = new Map();
gdjs.ingameCode.GDcomputerObjects1= [];
gdjs.ingameCode.GDcomputerObjects2= [];
gdjs.ingameCode.GDpower_9595bar_9595grnObjects1= [];
gdjs.ingameCode.GDpower_9595bar_9595grnObjects2= [];
gdjs.ingameCode.GDpwr_9595txtObjects1= [];
gdjs.ingameCode.GDpwr_9595txtObjects2= [];
gdjs.ingameCode.GDerror_9595txtObjects1= [];
gdjs.ingameCode.GDerror_9595txtObjects2= [];
gdjs.ingameCode.GDmenuObjects1= [];
gdjs.ingameCode.GDmenuObjects2= [];
gdjs.ingameCode.GDmonitorsObjects1= [];
gdjs.ingameCode.GDmonitorsObjects2= [];
gdjs.ingameCode.GDldoorObjects1= [];
gdjs.ingameCode.GDldoorObjects2= [];
gdjs.ingameCode.GDllightObjects1= [];
gdjs.ingameCode.GDllightObjects2= [];
gdjs.ingameCode.GDrdoorObjects1= [];
gdjs.ingameCode.GDrdoorObjects2= [];
gdjs.ingameCode.GDrlightObjects1= [];
gdjs.ingameCode.GDrlightObjects2= [];
gdjs.ingameCode.GDpower_9595controlObjects1= [];
gdjs.ingameCode.GDpower_9595controlObjects2= [];
gdjs.ingameCode.GDpower_9595bar_9595redObjects1= [];
gdjs.ingameCode.GDpower_9595bar_9595redObjects2= [];
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1= [];
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects2= [];
gdjs.ingameCode.GDposter_9595jaredObjects1= [];
gdjs.ingameCode.GDposter_9595jaredObjects2= [];
gdjs.ingameCode.GDrdoor_9595statusObjects1= [];
gdjs.ingameCode.GDrdoor_9595statusObjects2= [];
gdjs.ingameCode.GDldoor_9595statusObjects1= [];
gdjs.ingameCode.GDldoor_9595statusObjects2= [];
gdjs.ingameCode.GDllight_9595statusObjects1= [];
gdjs.ingameCode.GDllight_9595statusObjects2= [];
gdjs.ingameCode.GDrlight_9595statusObjects1= [];
gdjs.ingameCode.GDrlight_9595statusObjects2= [];
gdjs.ingameCode.GDlwindowObjects1= [];
gdjs.ingameCode.GDlwindowObjects2= [];
gdjs.ingameCode.GDtabletObjects1= [];
gdjs.ingameCode.GDtabletObjects2= [];


gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDpower_95959595bar_95959595ylwObjects1Objects = Hashtable.newFrom({"power_bar_ylw": gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1});
gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDpower_95959595bar_95959595redObjects1Objects = Hashtable.newFrom({"power_bar_red": gdjs.ingameCode.GDpower_9595bar_9595redObjects1});
gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDposter_95959595jaredObjects1Objects = Hashtable.newFrom({"poster_jared": gdjs.ingameCode.GDposter_9595jaredObjects1});
gdjs.ingameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.ingameCode.GDmenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDmenuObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDmenuObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDmenuObjects1[k] = gdjs.ingameCode.GDmenuObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDmenuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("power_control"), gdjs.ingameCode.GDpower_9595controlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595controlObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDpower_9595controlObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595controlObjects1[k] = gdjs.ingameCode.GDpower_9595controlObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595controlObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("power_bar_grn"), gdjs.ingameCode.GDpower_9595bar_9595grnObjects1);
gdjs.copyArray(runtimeScene.getObjects("power_bar_red"), gdjs.ingameCode.GDpower_9595bar_9595redObjects1);
gdjs.copyArray(runtimeScene.getObjects("power_bar_ylw"), gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1);
/* Reuse gdjs.ingameCode.GDpower_9595controlObjects1 */
{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595grnObjects1[i].SetValue((( gdjs.ingameCode.GDpower_9595controlObjects1.length === 0 ) ? 0 :gdjs.ingameCode.GDpower_9595controlObjects1[0].Value(null)), null);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595redObjects1[i].SetValue((( gdjs.ingameCode.GDpower_9595controlObjects1.length === 0 ) ? 0 :gdjs.ingameCode.GDpower_9595controlObjects1[0].Value(null)), null);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1[i].SetValue((( gdjs.ingameCode.GDpower_9595controlObjects1.length === 0 ) ? 0 :gdjs.ingameCode.GDpower_9595controlObjects1[0].Value(null)), null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.steamworks.setRichPresence("status", "Ingame - FNAA");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("power_bar_grn"), gdjs.ingameCode.GDpower_9595bar_9595grnObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDpower_9595bar_9595grnObjects1[i].Value(null) <= 65 ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595bar_9595grnObjects1[k] = gdjs.ingameCode.GDpower_9595bar_9595grnObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ingameCode.GDpower_9595bar_9595grnObjects1 */
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length = 0;

{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595grnObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDpower_95959595bar_95959595ylwObjects1Objects, 592, 430, "");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("power_bar_ylw"), gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1[i].Value(null) <= 25 ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1[k] = gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1 */
gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length = 0;

{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDpower_95959595bar_95959595redObjects1Objects, 592, 430, "");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("power_bar_red"), gdjs.ingameCode.GDpower_9595bar_9595redObjects1);
gdjs.copyArray(runtimeScene.getObjects("power_control"), gdjs.ingameCode.GDpower_9595controlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDpower_9595bar_9595redObjects1[i].Value(null) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595bar_9595redObjects1[k] = gdjs.ingameCode.GDpower_9595bar_9595redObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595controlObjects1.length;i<l;++i) {
    if ( !(gdjs.ingameCode.GDpower_9595controlObjects1[i].IsBeingDragged(null)) ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595controlObjects1[k] = gdjs.ingameCode.GDpower_9595controlObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595controlObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("error_txt"), gdjs.ingameCode.GDerror_9595txtObjects1);
gdjs.copyArray(runtimeScene.getObjects("ldoor"), gdjs.ingameCode.GDldoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("ldoor_status"), gdjs.ingameCode.GDldoor_9595statusObjects1);
gdjs.copyArray(runtimeScene.getObjects("llight"), gdjs.ingameCode.GDllightObjects1);
gdjs.copyArray(runtimeScene.getObjects("llight_status"), gdjs.ingameCode.GDllight_9595statusObjects1);
/* Reuse gdjs.ingameCode.GDpower_9595bar_9595redObjects1 */
gdjs.copyArray(runtimeScene.getObjects("pwr_txt"), gdjs.ingameCode.GDpwr_9595txtObjects1);
gdjs.copyArray(runtimeScene.getObjects("rdoor"), gdjs.ingameCode.GDrdoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("rdoor_status"), gdjs.ingameCode.GDrdoor_9595statusObjects1);
gdjs.copyArray(runtimeScene.getObjects("rlight"), gdjs.ingameCode.GDrlightObjects1);
gdjs.copyArray(runtimeScene.getObjects("rlight_status"), gdjs.ingameCode.GDrlight_9595statusObjects1);
{for(var i = 0, len = gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpower_9595bar_9595redObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDpwr_9595txtObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDpwr_9595txtObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDrlightObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDrlightObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDllightObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDllightObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDrdoorObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDrdoorObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDldoorObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDldoorObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDldoor_9595statusObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDldoor_9595statusObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDrlight_9595statusObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDrlight_9595statusObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDrdoor_9595statusObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDrdoor_9595statusObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDllight_9595statusObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDllight_9595statusObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDerror_9595txtObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDerror_9595txtObjects1[i].getBehavior("Text").setText("Power Offline. Attempting to restart generator...");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num9");
if (isConditionTrue_0) {
gdjs.ingameCode.GDposter_9595jaredObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.ingameCode.mapOfGDgdjs_9546ingameCode_9546GDposter_95959595jaredObjects1Objects, 28, 37, "");
}
{for(var i = 0, len = gdjs.ingameCode.GDposter_9595jaredObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDposter_9595jaredObjects1[i].getBehavior("Resizable").setSize(401, 227);
}
}
{for(var i = 0, len = gdjs.ingameCode.GDposter_9595jaredObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDposter_9595jaredObjects1[i].setAngle(351);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("power_control"), gdjs.ingameCode.GDpower_9595controlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ingameCode.GDpower_9595controlObjects1.length;i<l;++i) {
    if ( gdjs.ingameCode.GDpower_9595controlObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.ingameCode.GDpower_9595controlObjects1[k] = gdjs.ingameCode.GDpower_9595controlObjects1[i];
        ++k;
    }
}
gdjs.ingameCode.GDpower_9595controlObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("error_txt"), gdjs.ingameCode.GDerror_9595txtObjects1);
/* Reuse gdjs.ingameCode.GDpower_9595controlObjects1 */
{for(var i = 0, len = gdjs.ingameCode.GDerror_9595txtObjects1.length ;i < len;++i) {
    gdjs.ingameCode.GDerror_9595txtObjects1[i].getBehavior("Text").setText("Battery power levels: " + gdjs.evtTools.common.toString((( gdjs.ingameCode.GDpower_9595controlObjects1.length === 0 ) ? 0 :gdjs.ingameCode.GDpower_9595controlObjects1[0].Value(null))) + "% remaining");
}
}
}

}


};

gdjs.ingameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ingameCode.GDcomputerObjects1.length = 0;
gdjs.ingameCode.GDcomputerObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595grnObjects2.length = 0;
gdjs.ingameCode.GDpwr_9595txtObjects1.length = 0;
gdjs.ingameCode.GDpwr_9595txtObjects2.length = 0;
gdjs.ingameCode.GDerror_9595txtObjects1.length = 0;
gdjs.ingameCode.GDerror_9595txtObjects2.length = 0;
gdjs.ingameCode.GDmenuObjects1.length = 0;
gdjs.ingameCode.GDmenuObjects2.length = 0;
gdjs.ingameCode.GDmonitorsObjects1.length = 0;
gdjs.ingameCode.GDmonitorsObjects2.length = 0;
gdjs.ingameCode.GDldoorObjects1.length = 0;
gdjs.ingameCode.GDldoorObjects2.length = 0;
gdjs.ingameCode.GDllightObjects1.length = 0;
gdjs.ingameCode.GDllightObjects2.length = 0;
gdjs.ingameCode.GDrdoorObjects1.length = 0;
gdjs.ingameCode.GDrdoorObjects2.length = 0;
gdjs.ingameCode.GDrlightObjects1.length = 0;
gdjs.ingameCode.GDrlightObjects2.length = 0;
gdjs.ingameCode.GDpower_9595controlObjects1.length = 0;
gdjs.ingameCode.GDpower_9595controlObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595redObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects2.length = 0;
gdjs.ingameCode.GDposter_9595jaredObjects1.length = 0;
gdjs.ingameCode.GDposter_9595jaredObjects2.length = 0;
gdjs.ingameCode.GDrdoor_9595statusObjects1.length = 0;
gdjs.ingameCode.GDrdoor_9595statusObjects2.length = 0;
gdjs.ingameCode.GDldoor_9595statusObjects1.length = 0;
gdjs.ingameCode.GDldoor_9595statusObjects2.length = 0;
gdjs.ingameCode.GDllight_9595statusObjects1.length = 0;
gdjs.ingameCode.GDllight_9595statusObjects2.length = 0;
gdjs.ingameCode.GDrlight_9595statusObjects1.length = 0;
gdjs.ingameCode.GDrlight_9595statusObjects2.length = 0;
gdjs.ingameCode.GDlwindowObjects1.length = 0;
gdjs.ingameCode.GDlwindowObjects2.length = 0;
gdjs.ingameCode.GDtabletObjects1.length = 0;
gdjs.ingameCode.GDtabletObjects2.length = 0;

gdjs.ingameCode.eventsList0(runtimeScene);
gdjs.ingameCode.GDcomputerObjects1.length = 0;
gdjs.ingameCode.GDcomputerObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595grnObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595grnObjects2.length = 0;
gdjs.ingameCode.GDpwr_9595txtObjects1.length = 0;
gdjs.ingameCode.GDpwr_9595txtObjects2.length = 0;
gdjs.ingameCode.GDerror_9595txtObjects1.length = 0;
gdjs.ingameCode.GDerror_9595txtObjects2.length = 0;
gdjs.ingameCode.GDmenuObjects1.length = 0;
gdjs.ingameCode.GDmenuObjects2.length = 0;
gdjs.ingameCode.GDmonitorsObjects1.length = 0;
gdjs.ingameCode.GDmonitorsObjects2.length = 0;
gdjs.ingameCode.GDldoorObjects1.length = 0;
gdjs.ingameCode.GDldoorObjects2.length = 0;
gdjs.ingameCode.GDllightObjects1.length = 0;
gdjs.ingameCode.GDllightObjects2.length = 0;
gdjs.ingameCode.GDrdoorObjects1.length = 0;
gdjs.ingameCode.GDrdoorObjects2.length = 0;
gdjs.ingameCode.GDrlightObjects1.length = 0;
gdjs.ingameCode.GDrlightObjects2.length = 0;
gdjs.ingameCode.GDpower_9595controlObjects1.length = 0;
gdjs.ingameCode.GDpower_9595controlObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595redObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595redObjects2.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects1.length = 0;
gdjs.ingameCode.GDpower_9595bar_9595ylwObjects2.length = 0;
gdjs.ingameCode.GDposter_9595jaredObjects1.length = 0;
gdjs.ingameCode.GDposter_9595jaredObjects2.length = 0;
gdjs.ingameCode.GDrdoor_9595statusObjects1.length = 0;
gdjs.ingameCode.GDrdoor_9595statusObjects2.length = 0;
gdjs.ingameCode.GDldoor_9595statusObjects1.length = 0;
gdjs.ingameCode.GDldoor_9595statusObjects2.length = 0;
gdjs.ingameCode.GDllight_9595statusObjects1.length = 0;
gdjs.ingameCode.GDllight_9595statusObjects2.length = 0;
gdjs.ingameCode.GDrlight_9595statusObjects1.length = 0;
gdjs.ingameCode.GDrlight_9595statusObjects2.length = 0;
gdjs.ingameCode.GDlwindowObjects1.length = 0;
gdjs.ingameCode.GDlwindowObjects2.length = 0;
gdjs.ingameCode.GDtabletObjects1.length = 0;
gdjs.ingameCode.GDtabletObjects2.length = 0;


return;

}

gdjs['ingameCode'] = gdjs.ingameCode;
