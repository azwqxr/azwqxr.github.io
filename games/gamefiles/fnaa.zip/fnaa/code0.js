gdjs.menuCode = {};
gdjs.menuCode.localVariables = [];
gdjs.menuCode.idToCallbackMap = new Map();
gdjs.menuCode.GDmenu_9595backgroundObjects1= [];
gdjs.menuCode.GDmenu_9595backgroundObjects2= [];
gdjs.menuCode.GDplay_9595buttonObjects1= [];
gdjs.menuCode.GDplay_9595buttonObjects2= [];
gdjs.menuCode.GDwarningObjects1= [];
gdjs.menuCode.GDwarningObjects2= [];
gdjs.menuCode.GDaccount_9595buttonObjects1= [];
gdjs.menuCode.GDaccount_9595buttonObjects2= [];
gdjs.menuCode.GDxObjects1= [];
gdjs.menuCode.GDxObjects2= [];
gdjs.menuCode.GDlogin_9595textObjects1= [];
gdjs.menuCode.GDlogin_9595textObjects2= [];
gdjs.menuCode.GDfullscreenObjects1= [];
gdjs.menuCode.GDfullscreenObjects2= [];
gdjs.menuCode.GDmeme_9595nightObjects1= [];
gdjs.menuCode.GDmeme_9595nightObjects2= [];
gdjs.menuCode.GDjob_9595applicationObjects1= [];
gdjs.menuCode.GDjob_9595applicationObjects2= [];
gdjs.menuCode.GDexitObjects1= [];
gdjs.menuCode.GDexitObjects2= [];
gdjs.menuCode.GDsteam_9595workshopObjects1= [];
gdjs.menuCode.GDsteam_9595workshopObjects2= [];
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects1= [];
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects2= [];
gdjs.menuCode.GDsteamworkshop_9595successObjects1= [];
gdjs.menuCode.GDsteamworkshop_9595successObjects2= [];
gdjs.menuCode.GDblackscreenObjects1= [];
gdjs.menuCode.GDblackscreenObjects2= [];
gdjs.menuCode.GDworkshop_9595IDObjects1= [];
gdjs.menuCode.GDworkshop_9595IDObjects2= [];
gdjs.menuCode.GDtabletObjects1= [];
gdjs.menuCode.GDtabletObjects2= [];


gdjs.menuCode.asyncCallback13717068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.menuCode.localVariables);
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
gdjs.menuCode.localVariables.length = 0;
}
gdjs.menuCode.idToCallbackMap.set(13717068, gdjs.menuCode.asyncCallback13717068);
gdjs.menuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.menuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.menuCode.asyncCallback13717068(runtimeScene, asyncObjectsList)), 13717068, asyncObjectsList);
}
}

}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDjob_95959595applicationObjects1Objects = Hashtable.newFrom({"job_application": gdjs.menuCode.GDjob_9595applicationObjects1});
gdjs.menuCode.asyncCallback13718300 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.menuCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("job_application"), gdjs.menuCode.GDjob_9595applicationObjects2);

{for(var i = 0, len = gdjs.menuCode.GDjob_9595applicationObjects2.length ;i < len;++i) {
    gdjs.menuCode.GDjob_9595applicationObjects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.menuCode.localVariables.length = 0;
}
gdjs.menuCode.idToCallbackMap.set(13718300, gdjs.menuCode.asyncCallback13718300);
gdjs.menuCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.menuCode.localVariables);
for (const obj of gdjs.menuCode.GDjob_9595applicationObjects1) asyncObjectsList.addObject("job_application", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.menuCode.asyncCallback13718300(runtimeScene, asyncObjectsList)), 13718300, asyncObjectsList);
}
}

}


};gdjs.menuCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("play_button"), gdjs.menuCode.GDplay_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDplay_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.menuCode.GDplay_9595buttonObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDplay_9595buttonObjects1[k] = gdjs.menuCode.GDplay_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.menuCode.GDplay_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ingame", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("account_button"), gdjs.menuCode.GDaccount_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDaccount_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.menuCode.GDaccount_9595buttonObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDaccount_9595buttonObjects1[k] = gdjs.menuCode.GDaccount_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.menuCode.GDaccount_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.playerAuthentication.hasLoggedIn();
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("meme_night"), gdjs.menuCode.GDmeme_9595nightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDmeme_9595nightObjects1.length;i<l;++i) {
    if ( gdjs.menuCode.GDmeme_9595nightObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDmeme_9595nightObjects1[k] = gdjs.menuCode.GDmeme_9595nightObjects1[i];
        ++k;
    }
}
gdjs.menuCode.GDmeme_9595nightObjects1.length = k;
if (isConditionTrue_0) {
gdjs.menuCode.GDjob_9595applicationObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDjob_95959595applicationObjects1Objects, -(6), -(6), "");
}
{for(var i = 0, len = gdjs.menuCode.GDjob_9595applicationObjects1.length ;i < len;++i) {
    gdjs.menuCode.GDjob_9595applicationObjects1[i].getBehavior("Resizable").setSize(1294, 736);
}
}

{ //Subevents
gdjs.menuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.menuCode.GDexitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDexitObjects1.length;i<l;++i) {
    if ( gdjs.menuCode.GDexitObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDexitObjects1[k] = gdjs.menuCode.GDexitObjects1[i];
        ++k;
    }
}
gdjs.menuCode.GDexitObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.hasGameJustResumed(runtimeScene);
if (isConditionTrue_0) {
{gdjs.steamworks.setRichPresence("status", "Menu - FNAA");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.advancedWindow.isFocused(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "2020-10-26_-_Ghost_Stories_-_www.FesliyanStudios.com_Steve_Oxen.mp3", 1, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("steam_workshop"), gdjs.menuCode.GDsteam_9595workshopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDsteam_9595workshopObjects1.length;i<l;++i) {
    if ( gdjs.menuCode.GDsteam_9595workshopObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDsteam_9595workshopObjects1[k] = gdjs.menuCode.GDsteam_9595workshopObjects1[i];
        ++k;
    }
}
gdjs.menuCode.GDsteam_9595workshopObjects1.length = k;
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.playerAuthentication.isAuthenticated();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("login_text"), gdjs.menuCode.GDlogin_9595textObjects1);
{for(var i = 0, len = gdjs.menuCode.GDlogin_9595textObjects1.length ;i < len;++i) {
    gdjs.menuCode.GDlogin_9595textObjects1[i].getBehavior("Text").setText("Welcome," + gdjs.playerAuthentication.getUsername() + "!");
}
}
}

}


};

gdjs.menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.menuCode.GDmenu_9595backgroundObjects1.length = 0;
gdjs.menuCode.GDmenu_9595backgroundObjects2.length = 0;
gdjs.menuCode.GDplay_9595buttonObjects1.length = 0;
gdjs.menuCode.GDplay_9595buttonObjects2.length = 0;
gdjs.menuCode.GDwarningObjects1.length = 0;
gdjs.menuCode.GDwarningObjects2.length = 0;
gdjs.menuCode.GDaccount_9595buttonObjects1.length = 0;
gdjs.menuCode.GDaccount_9595buttonObjects2.length = 0;
gdjs.menuCode.GDxObjects1.length = 0;
gdjs.menuCode.GDxObjects2.length = 0;
gdjs.menuCode.GDlogin_9595textObjects1.length = 0;
gdjs.menuCode.GDlogin_9595textObjects2.length = 0;
gdjs.menuCode.GDfullscreenObjects1.length = 0;
gdjs.menuCode.GDfullscreenObjects2.length = 0;
gdjs.menuCode.GDmeme_9595nightObjects1.length = 0;
gdjs.menuCode.GDmeme_9595nightObjects2.length = 0;
gdjs.menuCode.GDjob_9595applicationObjects1.length = 0;
gdjs.menuCode.GDjob_9595applicationObjects2.length = 0;
gdjs.menuCode.GDexitObjects1.length = 0;
gdjs.menuCode.GDexitObjects2.length = 0;
gdjs.menuCode.GDsteam_9595workshopObjects1.length = 0;
gdjs.menuCode.GDsteam_9595workshopObjects2.length = 0;
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects1.length = 0;
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects2.length = 0;
gdjs.menuCode.GDsteamworkshop_9595successObjects1.length = 0;
gdjs.menuCode.GDsteamworkshop_9595successObjects2.length = 0;
gdjs.menuCode.GDblackscreenObjects1.length = 0;
gdjs.menuCode.GDblackscreenObjects2.length = 0;
gdjs.menuCode.GDworkshop_9595IDObjects1.length = 0;
gdjs.menuCode.GDworkshop_9595IDObjects2.length = 0;
gdjs.menuCode.GDtabletObjects1.length = 0;
gdjs.menuCode.GDtabletObjects2.length = 0;

gdjs.menuCode.eventsList2(runtimeScene);
gdjs.menuCode.GDmenu_9595backgroundObjects1.length = 0;
gdjs.menuCode.GDmenu_9595backgroundObjects2.length = 0;
gdjs.menuCode.GDplay_9595buttonObjects1.length = 0;
gdjs.menuCode.GDplay_9595buttonObjects2.length = 0;
gdjs.menuCode.GDwarningObjects1.length = 0;
gdjs.menuCode.GDwarningObjects2.length = 0;
gdjs.menuCode.GDaccount_9595buttonObjects1.length = 0;
gdjs.menuCode.GDaccount_9595buttonObjects2.length = 0;
gdjs.menuCode.GDxObjects1.length = 0;
gdjs.menuCode.GDxObjects2.length = 0;
gdjs.menuCode.GDlogin_9595textObjects1.length = 0;
gdjs.menuCode.GDlogin_9595textObjects2.length = 0;
gdjs.menuCode.GDfullscreenObjects1.length = 0;
gdjs.menuCode.GDfullscreenObjects2.length = 0;
gdjs.menuCode.GDmeme_9595nightObjects1.length = 0;
gdjs.menuCode.GDmeme_9595nightObjects2.length = 0;
gdjs.menuCode.GDjob_9595applicationObjects1.length = 0;
gdjs.menuCode.GDjob_9595applicationObjects2.length = 0;
gdjs.menuCode.GDexitObjects1.length = 0;
gdjs.menuCode.GDexitObjects2.length = 0;
gdjs.menuCode.GDsteam_9595workshopObjects1.length = 0;
gdjs.menuCode.GDsteam_9595workshopObjects2.length = 0;
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects1.length = 0;
gdjs.menuCode.GDsteam_9595wkshp_9595txtObjects2.length = 0;
gdjs.menuCode.GDsteamworkshop_9595successObjects1.length = 0;
gdjs.menuCode.GDsteamworkshop_9595successObjects2.length = 0;
gdjs.menuCode.GDblackscreenObjects1.length = 0;
gdjs.menuCode.GDblackscreenObjects2.length = 0;
gdjs.menuCode.GDworkshop_9595IDObjects1.length = 0;
gdjs.menuCode.GDworkshop_9595IDObjects2.length = 0;
gdjs.menuCode.GDtabletObjects1.length = 0;
gdjs.menuCode.GDtabletObjects2.length = 0;


return;

}

gdjs['menuCode'] = gdjs.menuCode;
