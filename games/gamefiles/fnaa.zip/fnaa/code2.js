gdjs.creditsCode = {};
gdjs.creditsCode.localVariables = [];
gdjs.creditsCode.idToCallbackMap = new Map();
gdjs.creditsCode.GDazwqxrObjects1= [];
gdjs.creditsCode.GDazwqxrObjects2= [];
gdjs.creditsCode.GDtxtObjects1= [];
gdjs.creditsCode.GDtxtObjects2= [];
gdjs.creditsCode.GDgdevelop_9595txtObjects1= [];
gdjs.creditsCode.GDgdevelop_9595txtObjects2= [];
gdjs.creditsCode.GDtabletObjects1= [];
gdjs.creditsCode.GDtabletObjects2= [];


gdjs.creditsCode.asyncCallback13811044 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.creditsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "warning", false);
}
gdjs.creditsCode.localVariables.length = 0;
}
gdjs.creditsCode.idToCallbackMap.set(13811044, gdjs.creditsCode.asyncCallback13811044);
gdjs.creditsCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.creditsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.creditsCode.asyncCallback13811044(runtimeScene, asyncObjectsList)), 13811044, asyncObjectsList);
}
}

}


};gdjs.creditsCode.asyncCallback13812276 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.creditsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("txt"), gdjs.creditsCode.GDtxtObjects2);
{for(var i = 0, len = gdjs.creditsCode.GDtxtObjects2.length ;i < len;++i) {
    gdjs.creditsCode.GDtxtObjects2[i].getBehavior("Text").setText("azwqxr's games\n\n      Welcome," + gdjs.steamworks.getName() + "!");
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "tada.wav", 2484345508, false, 100, 1);
}
gdjs.creditsCode.localVariables.length = 0;
}
gdjs.creditsCode.idToCallbackMap.set(13812276, gdjs.creditsCode.asyncCallback13812276);
gdjs.creditsCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.creditsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.creditsCode.asyncCallback13812276(runtimeScene, asyncObjectsList)), 13812276, asyncObjectsList);
}
}

}


};gdjs.creditsCode.asyncCallback13814332 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.creditsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("txt"), gdjs.creditsCode.GDtxtObjects2);
{for(var i = 0, len = gdjs.creditsCode.GDtxtObjects2.length ;i < len;++i) {
    gdjs.creditsCode.GDtxtObjects2[i].getBehavior("Text").setText("azwqxr's games\n\n      Welcome!");
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "tada.wav", 2484345508, false, 100, 1);
}
gdjs.creditsCode.localVariables.length = 0;
}
gdjs.creditsCode.idToCallbackMap.set(13814332, gdjs.creditsCode.asyncCallback13814332);
gdjs.creditsCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.creditsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.creditsCode.asyncCallback13814332(runtimeScene, asyncObjectsList)), 13814332, asyncObjectsList);
}
}

}


};gdjs.creditsCode.asyncCallback13816348 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.creditsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("txt"), gdjs.creditsCode.GDtxtObjects2);
{for(var i = 0, len = gdjs.creditsCode.GDtxtObjects2.length ;i < len;++i) {
    gdjs.creditsCode.GDtxtObjects2[i].getBehavior("Text").setText("azwqxr's games\n\n      Welcome," + gdjs.playerAuthentication.getUsername() + "!");
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "tada.wav", 2484345508, false, 100, 1);
}
gdjs.creditsCode.localVariables.length = 0;
}
gdjs.creditsCode.idToCallbackMap.set(13816348, gdjs.creditsCode.asyncCallback13816348);
gdjs.creditsCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.creditsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.creditsCode.asyncCallback13816348(runtimeScene, asyncObjectsList)), 13816348, asyncObjectsList);
}
}

}


};gdjs.creditsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.advancedWindow.isFocused(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("azwqxr"), gdjs.creditsCode.GDazwqxrObjects1);
{for(var i = 0, len = gdjs.creditsCode.GDazwqxrObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDazwqxrObjects1[i].rotate(100, runtimeScene);
}
}
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Five Nights At azwqxr's");
}
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}
{gdjs.evtTools.advancedWindow.setMinimizable(true, runtimeScene);
}
{gdjs.evtTools.advancedWindow.setMaximizable(false, runtimeScene);
}

{ //Subevents
gdjs.creditsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.advancedWindow.isFocused(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2484345508));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.steamworks.isSteamworksProperlyLoaded();
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}

{ //Subevents
gdjs.creditsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.advancedWindow.isFocused(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2484345508));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.steamworks.isSteamworksProperlyLoaded());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.playerAuthentication.isAuthenticated());
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}

{ //Subevents
gdjs.creditsCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.advancedWindow.isFocused(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2484345508));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.steamworks.isSteamworksProperlyLoaded());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.playerAuthentication.isAuthenticated();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}

{ //Subevents
gdjs.creditsCode.eventsList3(runtimeScene);} //End of subevents
}

}


};

gdjs.creditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.creditsCode.GDazwqxrObjects1.length = 0;
gdjs.creditsCode.GDazwqxrObjects2.length = 0;
gdjs.creditsCode.GDtxtObjects1.length = 0;
gdjs.creditsCode.GDtxtObjects2.length = 0;
gdjs.creditsCode.GDgdevelop_9595txtObjects1.length = 0;
gdjs.creditsCode.GDgdevelop_9595txtObjects2.length = 0;
gdjs.creditsCode.GDtabletObjects1.length = 0;
gdjs.creditsCode.GDtabletObjects2.length = 0;

gdjs.creditsCode.eventsList4(runtimeScene);
gdjs.creditsCode.GDazwqxrObjects1.length = 0;
gdjs.creditsCode.GDazwqxrObjects2.length = 0;
gdjs.creditsCode.GDtxtObjects1.length = 0;
gdjs.creditsCode.GDtxtObjects2.length = 0;
gdjs.creditsCode.GDgdevelop_9595txtObjects1.length = 0;
gdjs.creditsCode.GDgdevelop_9595txtObjects2.length = 0;
gdjs.creditsCode.GDtabletObjects1.length = 0;
gdjs.creditsCode.GDtabletObjects2.length = 0;


return;

}

gdjs['creditsCode'] = gdjs.creditsCode;
