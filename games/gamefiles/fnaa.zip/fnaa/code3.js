gdjs.warningCode = {};
gdjs.warningCode.localVariables = [];
gdjs.warningCode.idToCallbackMap = new Map();
gdjs.warningCode.GDviolence_9595warningObjects1= [];
gdjs.warningCode.GDviolence_9595warningObjects2= [];
gdjs.warningCode.GDtabletObjects1= [];
gdjs.warningCode.GDtabletObjects2= [];


gdjs.warningCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("violence_warning"), gdjs.warningCode.GDviolence_9595warningObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.warningCode.GDviolence_9595warningObjects1.length;i<l;++i) {
    if ( gdjs.warningCode.GDviolence_9595warningObjects1[i].IsYesClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.warningCode.GDviolence_9595warningObjects1[k] = gdjs.warningCode.GDviolence_9595warningObjects1[i];
        ++k;
    }
}
gdjs.warningCode.GDviolence_9595warningObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("violence_warning"), gdjs.warningCode.GDviolence_9595warningObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.warningCode.GDviolence_9595warningObjects1.length;i<l;++i) {
    if ( gdjs.warningCode.GDviolence_9595warningObjects1[i].IsNoClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.warningCode.GDviolence_9595warningObjects1[k] = gdjs.warningCode.GDviolence_9595warningObjects1[i];
        ++k;
    }
}
gdjs.warningCode.GDviolence_9595warningObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.steamworks.isLowViolence());
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}
}

}


};

gdjs.warningCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.warningCode.GDviolence_9595warningObjects1.length = 0;
gdjs.warningCode.GDviolence_9595warningObjects2.length = 0;
gdjs.warningCode.GDtabletObjects1.length = 0;
gdjs.warningCode.GDtabletObjects2.length = 0;

gdjs.warningCode.eventsList0(runtimeScene);
gdjs.warningCode.GDviolence_9595warningObjects1.length = 0;
gdjs.warningCode.GDviolence_9595warningObjects2.length = 0;
gdjs.warningCode.GDtabletObjects1.length = 0;
gdjs.warningCode.GDtabletObjects2.length = 0;


return;

}

gdjs['warningCode'] = gdjs.warningCode;
